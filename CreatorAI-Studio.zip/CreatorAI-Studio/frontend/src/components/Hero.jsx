function Hero() {
  return (
    <section className="h-[90vh] bg-black text-white flex flex-col justify-center items-center text-center px-4">

      <h1 className="text-6xl font-bold max-w-4xl leading-tight">
        AI-Powered Content Creation
        For Modern Creators 🚀
      </h1>

      <p className="text-gray-400 mt-6 text-lg max-w-2xl">
        Generate viral scripts, captions, thumbnails,
        and AI prompts in seconds.
      </p>

      <div className="mt-8 flex gap-4">
        <button className="bg-white text-black px-6 py-3 rounded-xl font-semibold hover:bg-gray-300 transition">
          Get Started
        </button>

        <button className="border border-gray-700 px-6 py-3 rounded-xl hover:bg-gray-900 transition">
          Learn More
        </button>
      </div>

    </section>
  );
}

export default Hero;