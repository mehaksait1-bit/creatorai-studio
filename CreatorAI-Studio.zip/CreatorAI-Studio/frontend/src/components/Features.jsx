function Features() {

  const features = [
    {
      title: "Viral Script Generator",
      desc: "Generate high-converting Instagram and YouTube scripts instantly."
    },
    {
      title: "AI Caption Creator",
      desc: "Create engaging captions and social media content in seconds."
    },
    {
      title: "Image Prompt Generator",
      desc: "Generate cinematic AI prompts for thumbnails and AI art."
    }
  ];

  return (
    <section className="bg-black text-white py-24 px-8">

      <div className="text-center mb-16">
        <h2 className="text-5xl font-bold">
          Powerful AI Tools
        </h2>

        <p className="text-gray-400 mt-4">
          Everything creators need in one platform.
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-8">

        {features.map((feature, index) => (
          <div
            key={index}
            className="bg-gray-900 border border-gray-800 rounded-2xl p-8 hover:scale-105 transition duration-300"
          >

            <h3 className="text-2xl font-semibold mb-4">
              {feature.title}
            </h3>

            <p className="text-gray-400">
              {feature.desc}
            </p>

          </div>
        ))}

      </div>

    </section>
  );
}

export default Features;