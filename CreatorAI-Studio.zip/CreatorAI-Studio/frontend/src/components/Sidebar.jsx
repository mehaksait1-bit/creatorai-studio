import { NavLink } from "react-router-dom";

function Sidebar() {

  const linkClasses = ({ isActive }) =>
    isActive
      ? "bg-white text-black px-4 py-3 rounded-xl font-semibold transition"
      : "text-gray-300 hover:bg-gray-800 hover:text-white px-4 py-3 rounded-xl transition";

  return (

    <div className="w-64 h-screen bg-gray-950 border-r border-gray-800 p-6 fixed">

      <h1 className="text-3xl font-bold text-white mb-12">
        CreatorAI 🚀
      </h1>

      <div className="flex flex-col gap-4">

        <NavLink
          to="/"
          className={linkClasses}
        >
          Dashboard
        </NavLink>

        <NavLink
          to="/script-generator"
          className={linkClasses}
        >
          Script Generator
        </NavLink>

        <NavLink
          to="/caption-generator"
          className={linkClasses}
        >
          Caption Generator
        </NavLink>

        <NavLink
          to="/image-prompts"
          className={linkClasses}
        >
          Image Prompts
        </NavLink>

        <NavLink
          to="/settings"
          className={linkClasses}
        >
          Settings
        </NavLink>

        <NavLink
          to="/hashtag-generator"
          className={linkClasses}
        >
          Hashtag Generator
        </NavLink>

        <NavLink
         to="/history"
        className={linkClasses}
        >
          History 📜
        </NavLink>

      </div>

    </div>

  );
}

export default Sidebar;