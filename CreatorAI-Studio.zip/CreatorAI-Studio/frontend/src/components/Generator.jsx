import { useState } from "react";

function Generator() {
  const [topic, setTopic] = useState("");
  const [result, setResult] = useState("");

  const generateScript = () => {
    if (!topic) {
      alert("Please enter a topic");
      return;
    }

    const t = topic.toLowerCase();

    let generatedText = "";

    if (t.includes("fitness")) {
      generatedText = `
🔥 Hook:
Still not seeing fitness results?

😩 Problem:
Most people train hard but ignore nutrition and recovery.

✅ Value:
1. Eat enough protein daily
2. Sleep 7–8 hours every night
3. Stay consistent for at least 90 days

🚀 CTA:
Follow for more fitness tips!
      `;
    } else if (t.includes("study")) {
      generatedText = `
🔥 Hook:
Studying for hours but forgetting everything?

😩 Problem:
Most students rely on passive reading.

✅ Value:
1. Use active recall
2. Practice previous questions
3. Revise with spaced repetition

🚀 CTA:
Save this before your next exam!
      `;
    } else if (t.includes("python") || t.includes("coding")) {
      generatedText = `
🔥 Hook:
Want to learn coding faster?

😩 Problem:
Most beginners watch tutorials but never build projects.

✅ Value:
1. Code every day
2. Build mini projects
3. Learn debugging skills

🚀 CTA:
Follow for more coding tips!
      `;
    } else if (t.includes("business")) {
      generatedText = `
🔥 Hook:
Why do most businesses fail?

😩 Problem:
They focus on products instead of customers.

✅ Value:
1. Solve real problems
2. Build customer trust
3. Listen to feedback

🚀 CTA:
Follow for more business insights!
      `;
    } else if (t.includes("ai")) {
      generatedText = `
🔥 Hook:
AI is changing everything!

😩 Problem:
Many people don't know where to start.

✅ Value:
1. Learn AI fundamentals
2. Experiment with AI tools
3. Build practical projects

🚀 CTA:
Follow for more AI updates!
      `;
    } else {
      generatedText = `
🔥 Hook:
Want to improve your skills faster?

😩 Problem:
Most people consume information but never take action.

✅ Value:
1. Learn consistently
2. Practice daily
3. Track your progress

🚀 CTA:
Follow for more growth tips!
      `;
    }

    setResult(generatedText);

    // Save to History
    const history =
      JSON.parse(localStorage.getItem("history")) || [];

    history.unshift(`📜 Script: ${topic}`);

    localStorage.setItem(
      "history",
      JSON.stringify(history)
    );
  };

  const downloadScript = () => {
    const element = document.createElement("a");

    const file = new Blob(
      [result],
      { type: "text/plain" }
    );

    element.href = URL.createObjectURL(file);
    element.download = "script.txt";

    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <div className="text-white p-10">

      <h1 className="text-5xl font-bold mb-6">
        AI Script Generator 🚀
      </h1>

      <div className="bg-gray-900 p-8 rounded-2xl border border-gray-800 max-w-3xl">

        <input
          type="text"
          placeholder="Enter topic..."
          value={topic}
          onChange={(e) => setTopic(e.target.value)}
          className="w-full p-4 rounded-xl bg-black border border-gray-700 mb-6 outline-none"
        />

        <button
          onClick={generateScript}
          className="bg-white text-black px-6 py-3 rounded-xl font-semibold"
        >
          Generate Script
        </button>

        {result && (

          <div className="mt-8">

            <div className="bg-black p-6 rounded-xl border border-gray-700 whitespace-pre-line">
              {result}
            </div>

            <div className="flex gap-4 mt-4">

              <button
                onClick={() =>
                  navigator.clipboard.writeText(result)
                }
                className="bg-gray-800 hover:bg-gray-700 px-5 py-3 rounded-xl transition"
              >
                Copy Script 📋
              </button>

              <button
                onClick={downloadScript}
                className="bg-green-600 hover:bg-green-500 px-5 py-3 rounded-xl transition"
              >
                Download Script 📥
              </button>

            </div>

          </div>

        )}

      </div>

    </div>
  );
}

export default Generator;