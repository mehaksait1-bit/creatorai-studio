function Navbar() {
  return (
    <nav className="flex justify-between items-center px-8 py-5 bg-black text-white border-b border-gray-800">
      
      <h1 className="text-2xl font-bold">
        CreatorAI 🚀
      </h1>

      <div className="flex gap-6 items-center">
        <a href="#" className="hover:text-gray-400">Home</a>
        <a href="#" className="hover:text-gray-400">Features</a>
        <a href="#" className="hover:text-gray-400">About</a>

        <button className="bg-white text-black px-4 py-2 rounded-lg font-semibold hover:bg-gray-300 transition">
          Login
        </button>
      </div>

    </nav>
  );
}

export default Navbar;