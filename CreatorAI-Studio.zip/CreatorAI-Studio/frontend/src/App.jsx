import { BrowserRouter, Routes, Route } from "react-router-dom";

import Sidebar from "./components/Sidebar";

import Dashboard from "./pages/Dashboard";
import ScriptGenerator from "./pages/ScriptGenerator";
import ImagePrompts from "./pages/ImagePrompts";
import Settings from "./pages/Settings";
import CaptionGenerator from "./pages/CaptionGenerator";
import HashtagGenerator from "./pages/HashtagGenerator";
import History from "./pages/History";
function App() {

  return (

    <BrowserRouter>

      <div className="bg-black min-h-screen flex">

        <Sidebar />

        <div className="ml-64 w-full">

          <Routes>

            <Route
              path="/"
              element={<Dashboard />}
            />

            <Route
              path="/script-generator"
              element={<ScriptGenerator />}
            />
            <Route
              path="/caption-generator"
              element={<CaptionGenerator />}
            />
            <Route
              path="/image-prompts"
              element={<ImagePrompts />}
            />

            <Route
              path="/settings"
              element={<Settings />}
            />

            <Route
              path="/hashtag-generator"
              element={<HashtagGenerator />}
            />

            <Route 
              path="/history" 
              element={<History />}
            />

          </Routes>

        </div>

      </div>

    </BrowserRouter>

  );
}

export default App;