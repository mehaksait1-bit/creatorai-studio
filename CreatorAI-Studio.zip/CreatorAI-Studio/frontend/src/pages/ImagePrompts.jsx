import { useState } from "react";

function ImagePrompts() {

  const [idea, setIdea] = useState("");
  const [prompt, setPrompt] = useState("");

  const generatePrompt = () => {

    if (!idea) {
      alert("Enter an idea");
      return;
    }

    const text = idea.toLowerCase();

    if (text.includes("car")) {

      setPrompt(`
Luxury sports car, cinematic photography, ultra realistic 4K, sunset lighting, glossy reflections, dramatic atmosphere, highly detailed, professional automotive photography, masterpiece quality
      `);

    }

    else if (text.includes("space")) {

      setPrompt(`
Deep space galaxy, colorful nebula, glowing stars, ultra realistic 4K, cinematic lighting, futuristic atmosphere, NASA quality, highly detailed, breathtaking cosmic view
      `);

    }

    else if (text.includes("nature")) {

      setPrompt(`
Beautiful mountain landscape, crystal clear lake, golden sunrise, ultra realistic 4K, HDR photography, highly detailed, cinematic composition, masterpiece quality
      `);

    }

    else if (text.includes("ai")) {

      setPrompt(`
Advanced artificial intelligence robot, futuristic cyberpunk city, neon lights, ultra realistic 4K, cinematic atmosphere, volumetric lighting, highly detailed, science fiction masterpiece
      `);

    }

    else if (text.includes("fantasy")) {

      setPrompt(`
Fantasy kingdom, magical castle, dragons flying in the sky, ultra realistic 4K, cinematic lighting, epic fantasy environment, highly detailed, masterpiece quality
      `);

    }

    else {

      setPrompt(`
${idea}, cinematic style, ultra realistic 4K, HDR lighting, highly detailed, professional photography, dramatic shadows, sharp focus, masterpiece quality
      `);

    }

  };

  const downloadPrompt = () => {

    const element = document.createElement("a");

    const file = new Blob([prompt], {
      type: "text/plain",
    });

    element.href = URL.createObjectURL(file);
    element.download = "image-prompt.txt";

    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);

  };

  return (

    <div className="text-white p-10">

      <h1 className="text-5xl font-bold mb-6">
        AI Image Prompt Generator 🎨
      </h1>

      <div className="bg-gray-900 p-8 rounded-2xl border border-gray-800 max-w-4xl">

        <input
          type="text"
          placeholder="Enter image idea..."
          value={idea}
          onChange={(e) => setIdea(e.target.value)}
          className="w-full p-4 rounded-xl bg-black border border-gray-700 mb-6 outline-none"
        />

        <button
          onClick={generatePrompt}
          className="bg-white text-black px-6 py-3 rounded-xl font-semibold"
        >
          Generate Prompt
        </button>

        {prompt && (

          <div className="mt-8">

            <div className="bg-black p-6 rounded-xl border border-gray-700 whitespace-pre-line">
              {prompt}
            </div>

            <div className="flex gap-4 mt-4">

              <button
                onClick={() =>
                  navigator.clipboard.writeText(prompt)
                }
                className="bg-gray-800 hover:bg-gray-700 px-5 py-3 rounded-xl"
              >
                Copy Prompt 📋
              </button>

              <button
                onClick={downloadPrompt}
                className="bg-green-600 hover:bg-green-500 px-5 py-3 rounded-xl"
              >
                Download Prompt 📥
              </button>

            </div>

          </div>

        )}

      </div>

    </div>

  );
}

export default ImagePrompts;