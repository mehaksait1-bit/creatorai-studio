import { useState } from "react";

function CaptionGenerator() {
  const [topic, setTopic] = useState("");
  const [caption, setCaption] = useState("");

  const generateCaption = () => {
    if (!topic) {
      alert("Please enter a topic");
      return;
    }

    const t = topic.toLowerCase();

    let generatedCaption = "";

    if (t.includes("fitness")) {
      generatedCaption =
        "💪 Success doesn't come from what you do occasionally. It comes from what you do consistently. Stay focused, stay disciplined, and keep pushing forward. #fitness #gym #motivation";
    } else if (t.includes("study")) {
      generatedCaption =
        "📚 Every hour you spend learning today is an investment in your future. Stay focused, stay curious, and never stop growing. #study #studentlife #success";
    } else if (t.includes("python") || t.includes("coding")) {
      generatedCaption =
        "💻 The best way to learn coding isn't by watching tutorials—it's by building projects. Start small, stay consistent, and keep shipping. #coding #python #developer";
    } else if (t.includes("business")) {
      generatedCaption =
        "🚀 Great businesses solve real problems. Focus on creating value, and success will follow. #business #entrepreneur #startup";
    } else if (t.includes("ai")) {
      generatedCaption =
        "🤖 AI isn't replacing creativity—it's amplifying it. Learn the tools today to stay ahead tomorrow. #AI #technology #innovation";
    } else {
      generatedCaption =
        "✨ Small steps taken every day create massive results over time. Stay consistent and trust the process. #growth #success #motivation";
    }

    setCaption(generatedCaption);

    // Save to History
    const history =
      JSON.parse(localStorage.getItem("history")) || [];

    history.unshift(`✍️ Caption: ${topic}`);

    localStorage.setItem(
      "history",
      JSON.stringify(history)
    );
  };

  const downloadCaption = () => {
    const element = document.createElement("a");

    const file = new Blob([caption], {
      type: "text/plain",
    });

    element.href = URL.createObjectURL(file);
    element.download = "caption.txt";

    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <div className="text-white p-10">
      <h1 className="text-5xl font-bold mb-6">
        Caption Generator ✍️
      </h1>

      <div className="bg-gray-900 p-8 rounded-2xl border border-gray-800 max-w-3xl">

        <input
          type="text"
          placeholder="Enter topic..."
          value={topic}
          onChange={(e) => setTopic(e.target.value)}
          className="w-full p-4 rounded-xl bg-black border border-gray-700 mb-6 outline-none"
        />

        <button
          onClick={generateCaption}
          className="bg-white text-black px-6 py-3 rounded-xl font-semibold"
        >
          Generate Caption
        </button>

        {caption && (
          <div className="mt-8">

            <div className="bg-black p-6 rounded-xl border border-gray-700">
              {caption}
            </div>

            <div className="flex gap-4 mt-4">

              <button
                onClick={() =>
                  navigator.clipboard.writeText(caption)
                }
                className="bg-gray-800 hover:bg-gray-700 px-5 py-3 rounded-xl"
              >
                Copy Caption 📋
              </button>

              <button
                onClick={downloadCaption}
                className="bg-green-600 hover:bg-green-500 px-5 py-3 rounded-xl"
              >
                Download Caption 📥
              </button>

            </div>

          </div>
        )}

      </div>
    </div>
  );
}

export default CaptionGenerator;