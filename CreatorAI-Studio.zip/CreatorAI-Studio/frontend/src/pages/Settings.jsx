import { useState } from "react";

function Settings() {

  const [message, setMessage] = useState("");

  const clearHistory = () => {
    localStorage.removeItem("history");
    setMessage("History cleared successfully ✅");
  };

  return (
    <div className="text-white p-10">

      <h1 className="text-5xl font-bold mb-6">
        Settings ⚙️
      </h1>

      <div className="bg-gray-900 p-8 rounded-2xl border border-gray-800 max-w-3xl space-y-6">

        {/* App Info */}
        <div>
          <h2 className="text-2xl font-bold mb-2">
            App Info
          </h2>

          <p className="text-gray-300">
            CreatorAI Studio v1.0
          </p>

          <p className="text-gray-400 mt-2">
            AI-powered content generator platform
          </p>
        </div>

        {/* Actions */}
        <div>
          <h2 className="text-2xl font-bold mb-2">
            Actions
          </h2>

          <button
            onClick={clearHistory}
            className="bg-red-600 hover:bg-red-500 px-5 py-3 rounded-xl"
          >
            Clear History 🗑
          </button>

          {message && (
            <p className="mt-3 text-green-400">
              {message}
            </p>
          )}
        </div>

      </div>
    </div>
  );
}

export default Settings;