import Generator from "../components/Generator";

function ScriptGenerator() {
  return <Generator />;
}

export default ScriptGenerator;