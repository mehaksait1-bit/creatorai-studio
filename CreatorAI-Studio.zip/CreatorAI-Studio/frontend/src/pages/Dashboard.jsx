import { useEffect, useState } from "react";

function Dashboard() {

  const [stats, setStats] = useState({
    scripts: 0,
    captions: 0,
    hashtags: 0,
    prompts: 0
  });

  useEffect(() => {
    const history =
      JSON.parse(localStorage.getItem("history")) || [];

    let scripts = 0;
    let captions = 0;
    let hashtags = 0;
    let prompts = 0;

    history.forEach((item) => {
      if (item.startsWith("📜")) scripts++;
      else if (item.startsWith("✍️")) captions++;
      else if (item.startsWith("#️⃣")) hashtags++;
      else if (item.startsWith("🎨")) prompts++;
    });

    setStats({ scripts, captions, hashtags, prompts });

  }, []);

  return (
    <div className="text-white p-10">

      <h1 className="text-5xl font-bold mb-8">
        Dashboard 📊
      </h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl">

        <div className="bg-gray-900 p-6 rounded-2xl border border-gray-800">
          <h2 className="text-xl">Scripts Generated</h2>
          <p className="text-3xl font-bold mt-2">{stats.scripts}</p>
        </div>

        <div className="bg-gray-900 p-6 rounded-2xl border border-gray-800">
          <h2 className="text-xl">Captions Generated</h2>
          <p className="text-3xl font-bold mt-2">{stats.captions}</p>
        </div>

        <div className="bg-gray-900 p-6 rounded-2xl border border-gray-800">
          <h2 className="text-xl">Hashtags Generated</h2>
          <p className="text-3xl font-bold mt-2">{stats.hashtags}</p>
        </div>

        <div className="bg-gray-900 p-6 rounded-2xl border border-gray-800">
          <h2 className="text-xl">Prompts Generated</h2>
          <p className="text-3xl font-bold mt-2">{stats.prompts}</p>
        </div>

      </div>
    </div>
  );
}

export default Dashboard;