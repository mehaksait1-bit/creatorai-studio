import { useState, useEffect } from "react";

function History() {

  const [history, setHistory] = useState([]);

  useEffect(() => {
    const data =
      JSON.parse(localStorage.getItem("history")) || [];
    setHistory(data);
  }, []);

  const clearAll = () => {
    localStorage.removeItem("history");
    setHistory([]);
  };

  const deleteItem = (index) => {
    const updated = [...history];
    updated.splice(index, 1);
    setHistory(updated);
    localStorage.setItem("history", JSON.stringify(updated));
  };

  return (
    <div className="text-white p-10">

      <h1 className="text-5xl font-bold mb-6">
        History 📜
      </h1>

      <div className="flex justify-between items-center mb-6">

        <p className="text-gray-400">
          Total Items: {history.length}
        </p>

        <button
          onClick={clearAll}
          className="bg-red-600 hover:bg-red-500 px-4 py-2 rounded-xl"
        >
          Clear All 🗑
        </button>

      </div>

      <div className="space-y-4">

        {history.length === 0 ? (
          <p className="text-gray-400">
            No history yet.
          </p>
        ) : (
          history.map((item, index) => (
            <div
              key={index}
              className="bg-gray-900 p-4 rounded-xl border border-gray-800 flex justify-between items-center"
            >
              <span>{item}</span>

              <button
                onClick={() => deleteItem(index)}
                className="text-red-400 hover:text-red-300"
              >
                Delete
              </button>
            </div>
          ))
        )}

      </div>

    </div>
  );
}

export default History;