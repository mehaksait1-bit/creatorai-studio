import { useState } from "react";

function HashtagGenerator() {
  const [topic, setTopic] = useState("");
  const [hashtags, setHashtags] = useState("");

  const generateHashtags = () => {
    if (!topic) {
      alert("Enter a topic");
      return;
    }

    const t = topic.toLowerCase();

    if (t.includes("fitness")) {
      setHashtags(`
#fitness
#workout
#gym
#fitlife
#healthylifestyle
#fitnessmotivation
#exercise
#training
#fitnessjourney
#gymmotivation
      `);
    }

    else if (t.includes("python") || t.includes("coding")) {
      setHashtags(`
#coding
#python
#programming
#developer
#webdevelopment
#javascript
#codinglife
#tech
#softwaredeveloper
#code
      `);
    }

    else if (t.includes("ai") || t.includes("artificial intelligence")) {
      setHashtags(`
#ai
#artificialintelligence
#machinelearning
#chatgpt
#technology
#futuretech
#innovation
#generativeai
#datascience
#automation
      `);
    }

    else if (t.includes("business")) {
      setHashtags(`
#business
#entrepreneur
#startup
#marketing
#leadership
#success
#businessgrowth
#money
#branding
#entrepreneurship
      `);
    }

    else if (t.includes("study") || t.includes("education")) {
      setHashtags(`
#study
#studentlife
#education
#studytips
#learning
#motivation
#college
#examprep
#studymotivation
#success
      `);
    }

    else {
      setHashtags(`
#viral
#trending
#creator
#contentcreator
#socialmedia
#marketing
#growth
#explorepage
#reels
#success
      `);
    }
  };

  return (
    <div className="text-white p-10">
      <h1 className="text-5xl font-bold mb-6">
        Hashtag Generator #️⃣
      </h1>

      <div className="bg-gray-900 p-8 rounded-2xl border border-gray-800 max-w-3xl">

        <input
          type="text"
          placeholder="Enter topic..."
          value={topic}
          onChange={(e) => setTopic(e.target.value)}
          className="w-full p-4 rounded-xl bg-black border border-gray-700 mb-6 outline-none"
        />

        <button
          onClick={generateHashtags}
          className="bg-white text-black px-6 py-3 rounded-xl font-semibold"
        >
          Generate Hashtags
        </button>

        {hashtags && (
          <div className="mt-8">

            <div className="bg-black p-6 rounded-xl border border-gray-700 whitespace-pre-line">
              {hashtags}
            </div>

            <button
              onClick={() => navigator.clipboard.writeText(hashtags)}
              className="mt-4 bg-gray-800 hover:bg-gray-700 px-5 py-3 rounded-xl transition"
            >
              Copy Hashtags 📋
            </button>

          </div>
        )}

      </div>
    </div>
  );
}

export default HashtagGenerator;