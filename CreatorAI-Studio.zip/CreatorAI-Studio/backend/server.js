import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import { GoogleGenerativeAI } from "@google/generative-ai";

dotenv.config();

const app = express();

app.use(cors());
app.use(express.json());

const genAI = new GoogleGenerativeAI(
  process.env.GEMINI_API_KEY
);

app.post("/generate-script", async (req, res) => {

  try {

    const { topic } = req.body;

    const model = genAI.getGenerativeModel({
      model: "gemini-2.0-flash",
    });

    const prompt = `
Create a viral Instagram reel script about:

${topic}

Format:

🔥 Hook

😩 Problem

✅ 3 Value Points

🚀 CTA

Keep it engaging and easy to understand.
`;

    const result = await model.generateContent(
      prompt
    );

    const response =
      result.response.text();

    res.json({
      result: response,
    });

  } catch (error) {

    console.error(error);

    res.status(500).json({
      error: "Something went wrong",
    });

  }

});

app.listen(5000, () => {
  console.log(
    "Server running on port 5000"
  );
});